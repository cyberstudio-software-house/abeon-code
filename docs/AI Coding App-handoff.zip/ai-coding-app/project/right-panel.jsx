// Right panel — runnable actions (from package.json) + git status for the session.

function RightPanel() {
  return (
    <aside className="flex flex-col min-h-0 border-l border-line bg-bg">
      <ActionsSection />
      <GitSection />
    </aside>
  );
}

/* ───── Actions ───── */

function ActionsSection() {
  return (
    <div className="px-[18px] pt-[18px] pb-3.5">
      <div className="flex items-baseline justify-between">
        <div className="text-[10px] tracking-[0.14em] uppercase text-ink-3 font-medium">
          Akcje
        </div>
        <span className="text-[10px] text-ink-3 font-mono">z package.json</span>
      </div>
      <div className="mt-2.5 flex flex-col gap-1">
        {ACTIONS.map((a) => <ActionRow key={a.id} action={a} />)}
      </div>
      <button className="mt-2 w-full border border-dashed border-line bg-transparent px-2.5 py-[7px] rounded-md text-[11.5px] text-ink-3 hover:text-ink-2 hover:border-ink-3 transition-colors">
        + dodaj akcję
      </button>
    </div>
  );
}

function ActionRow({ action: a }) {
  return (
    <button
      className={`group w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-md transition-colors
        ${a.running
          ? 'bg-surface border border-line'
          : 'border border-transparent hover:bg-surface-soft'
        }`}
    >
      {a.running ? (
        <span className="inline-flex items-center justify-center w-[18px] h-[18px] rounded-xs bg-accent-soft text-accent-ink">
          <Icon name="pause" className="w-2.5 h-2.5" />
        </span>
      ) : (
        <span className="inline-flex items-center justify-center w-[18px] h-[18px] rounded-xs border border-line text-ink-2 group-hover:text-ink group-hover:border-ink-3 transition-colors">
          <Icon name="play" className="w-2.5 h-2.5" />
        </span>
      )}
      <div className="min-w-0 flex-1 text-left">
        <div className="font-mono text-[12px] text-ink truncate">{a.label}</div>
        <div className="text-[10px] text-ink-3 mt-px">
          {a.hint}
          {a.running && <span className="text-accent-ink"> · uruchomione · :{a.port}</span>}
        </div>
      </div>
      <Kbd>{a.kbd}</Kbd>
    </button>
  );
}

/* ───── Git ───── */

function GitSection() {
  return (
    <div className="border-t border-line px-[18px] pt-4 pb-[18px] flex-1 flex flex-col min-h-0">
      <div className="flex items-baseline justify-between">
        <div className="text-[10px] tracking-[0.14em] uppercase text-ink-3 font-medium">
          Zmiany
        </div>
        <span className="text-[10px] text-ink-3 font-mono">
          {GIT.files.length} plików
        </span>
      </div>

      <div className="mt-2.5 flex items-center gap-2 px-2.5 py-[7px] border border-line bg-surface rounded-md font-mono text-[11px] text-ink-2">
        <Icon name="branch" className="w-[11px] h-[11px]" />
        <span className="text-ink">{GIT.branch}</span>
        <span className="ml-auto text-ink-3">↑{GIT.ahead} ↓{GIT.behind}</span>
      </div>

      <div className="mt-2.5 flex flex-col flex-1 overflow-y-auto scroll-thin">
        {GIT.files.map((f, i) => <GitRow key={i} file={f} />)}
      </div>

      <div className="mt-3.5 flex gap-1.5">
        <GitBtn>diff</GitBtn>
        <GitBtn>stash</GitBtn>
        <GitBtn>commit…</GitBtn>
      </div>
    </div>
  );
}

function GitRow({ file: f }) {
  const tone = {
    M: 'text-warn',
    A: 'text-good',
    D: 'text-bad',
  }[f.status];
  return (
    <button className="flex items-center gap-2 px-2 py-[5px] border-b border-line-soft hover:bg-surface-soft transition-colors text-left">
      <span className={`font-mono text-[10px] w-3 text-center font-semibold ${tone}`}>
        {f.status}
      </span>
      <span className="flex-1 min-w-0 font-mono text-[11.5px] text-ink path-ellipsis">
        {f.path}
      </span>
      <span className="font-mono text-[10px] text-good tabular-nums">+{f.add}</span>
      <span className="font-mono text-[10px] text-bad tabular-nums">−{f.del}</span>
    </button>
  );
}

function GitBtn({ children }) {
  return (
    <button className="flex-1 border border-line bg-surface px-2.5 py-[7px] rounded-md text-[11.5px] text-ink-2 hover:text-ink hover:bg-surface-soft transition-colors">
      {children}
    </button>
  );
}

Object.assign(window, { RightPanel });
