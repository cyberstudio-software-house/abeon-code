// Left sidebar — projects with collapsible sessions.
// Top: search. Middle: scrollable project list. Bottom: user/model.

function Sidebar() {
  return (
    <aside className="flex flex-col min-h-0 border-r border-line bg-bg">
      <SidebarHeader />
      <div className="flex-1 overflow-y-auto scroll-thin px-1.5 pb-3">
        {PROJECTS.map((p) => <SidebarProject key={p.id} project={p} />)}
      </div>
      <SidebarFooter />
    </aside>
  );
}

function SidebarHeader() {
  return (
    <div className="px-[18px] pt-[18px] pb-2.5">
      <div className="text-[10px] tracking-[0.14em] uppercase text-ink-3 font-medium">
        Projekty
      </div>
      <div className="mt-2.5 flex items-center gap-2 px-2.5 py-[7px] bg-surface border border-line rounded-md">
        <Icon name="search" className="w-[13px] h-[13px] text-ink-3" />
        <span className="text-[12px] text-ink-3 flex-1">Szukaj projektu lub sesji…</span>
        <Kbd>⌘K</Kbd>
      </div>
    </div>
  );
}

function SidebarProject({ project }) {
  const open = project.open;
  return (
    <div className="py-0.5">
      <button
        className={`group w-full flex items-center gap-2 px-2.5 py-[7px] rounded-md text-left transition-colors
          ${open
            ? 'bg-surface border border-line'
            : 'border border-transparent hover:bg-surface-soft'
          }`}
      >
        <Icon
          name="chevR"
          className={`w-2.5 h-2.5 text-ink-2 transition-transform ${open ? 'rotate-90' : ''}`}
          strokeWidth={2.5}
        />
        <div className="min-w-0 flex-1">
          <div className={`text-[12.5px] truncate ${open ? 'font-semibold text-ink' : 'font-medium text-ink'}`}>
            {project.name}
          </div>
          <div className="font-mono text-[10px] text-ink-3 mt-px truncate">
            {project.path}
          </div>
        </div>
        {project.live > 0 && (
          <span
            className="w-1.5 h-1.5 rounded-full bg-accent"
            title={`${project.live} aktywnych sesji`}
          />
        )}
        <span className="font-mono text-[10px] text-ink-3 tabular-nums">{project.sessions}</span>
      </button>

      {open && (
        <div className="mt-1 mb-2.5 ml-4 pl-2.5 border-l border-line">
          {SESSIONS.map((s) => <SidebarSession key={s.id} session={s} />)}
          <SidebarLoadMore count={19} />
        </div>
      )}
    </div>
  );
}

function SidebarSession({ session: s }) {
  return (
    <button
      className={`group w-full flex items-center gap-2.5 px-2 py-[6px] rounded-sm text-left transition-colors
        ${s.active ? 'bg-accent-soft' : 'hover:bg-surface-soft'}`}
    >
      <span
        className={`w-1.5 h-1.5 rounded-full shrink-0
          ${s.active ? 'bg-accent' : 'bg-ink-3 opacity-40'}`}
      />
      <div className="min-w-0 flex-1">
        <div className={`text-[12px] truncate
          ${s.active ? 'text-accent-ink font-medium' : 'text-ink'}`}>
          {s.title}
        </div>
        <div className={`font-mono text-[10px] mt-px
          ${s.active ? 'text-accent-ink opacity-70' : 'text-ink-3'}`}>
          {s.id} · {s.turns} tur · {s.when}
        </div>
      </div>
    </button>
  );
}

function SidebarLoadMore({ count }) {
  return (
    <button className="mt-1 w-full flex items-center gap-2 px-2 py-[6px] rounded-sm text-left text-[11.5px] text-ink-3 hover:text-ink-2 hover:bg-surface-soft transition-colors">
      <Icon name="chevD" className="w-2.5 h-2.5" strokeWidth={2} />
      Załaduj {count} starszych
    </button>
  );
}

function SidebarFooter() {
  return (
    <div className="border-t border-line px-[18px] py-2.5 flex items-center gap-2.5">
      <div className="w-6 h-6 rounded-full bg-accent-soft text-accent-ink flex items-center justify-center text-[11px] font-semibold">
        MK
      </div>
      <div className="leading-tight">
        <div className="text-[12px] font-medium">Marek K.</div>
        <div className="font-mono text-[10px] text-ink-3">claude-sonnet-4-5</div>
      </div>
      <button className="ml-auto text-ink-3 hover:text-ink transition-colors" aria-label="Ustawienia">
        <Icon name="settings" className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}

Object.assign(window, { Sidebar });
