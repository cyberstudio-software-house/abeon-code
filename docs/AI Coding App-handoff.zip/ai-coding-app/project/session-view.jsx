// Center panel — session preview.
// Header (breadcrumb + title + stats) → "read-only" pill → transcript → footer CTA.

function SessionView() {
  return (
    <main className="flex flex-col min-h-0 bg-bg">
      <SessionHeader />
      <div className="flex-1 overflow-y-auto scroll-thin px-7 py-[18px]">
        <ReadOnlyPill />
        <div className="flex flex-col gap-[22px] mt-[18px]">
          {HISTORY.map((m, i) => <Turn key={i} message={m} />)}
        </div>
      </div>
      <SessionFooter />
    </main>
  );
}

function SessionHeader() {
  return (
    <div className="px-7 pt-[18px] pb-3.5 border-b border-line">
      <div className="font-mono text-[10px] text-ink-3 tracking-wide">
        monorepo-web · sesja s-9af2 · rozpoczęta 12 min temu
      </div>
      <div className="mt-1.5 flex items-baseline gap-3.5">
        <h1 className="m-0 text-[20px] font-medium tracking-[-0.3px]">
          Build session manager UI
        </h1>
        <span className="inline-flex items-center gap-1.5 text-[10px] font-mono text-accent-ink bg-accent-soft px-[7px] py-0.5 rounded-full">
          <span className="w-1 h-1 rounded-full bg-accent" />
          aktywna
        </span>
        <div className="ml-auto flex gap-1.5">
          <IconBtn icon="copy"   label="Kopiuj ID sesji" />
          <IconBtn icon="branch" label="Fork sesji" />
          <IconBtn icon="more"   label="Więcej akcji" />
        </div>
      </div>
      <div className="mt-2.5 flex gap-[18px] text-[11px] text-ink-2 font-mono">
        <span>47 tur</span>
        <span className="text-ink-3">·</span>
        <span>↑ 184k  ↓ 41k tokenów</span>
        <span className="text-ink-3">·</span>
        <span>$1.84</span>
        <span className="text-ink-3">·</span>
        <span>14 narzędzi</span>
      </div>
    </div>
  );
}

function ReadOnlyPill() {
  return (
    <div className="inline-flex items-center gap-1.5 text-[11px] text-ink-2 border border-line bg-surface px-2.5 py-1 rounded-full font-mono">
      <Icon name="clock" className="w-[11px] h-[11px]" />
      Podgląd historii — sesja nie jest aktualnie uruchomiona
    </div>
  );
}

function Turn({ message: m }) {
  const isUser = m.role === 'user';
  return (
    <div className="grid grid-cols-[72px_1fr] gap-3.5">
      <div className="font-mono text-[10px] text-ink-3 pt-0.5 tracking-wide">
        {isUser ? 'TY' : 'CLAUDE'}
      </div>
      <div>
        <div className={`text-[13.5px] leading-[1.6] max-w-[640px] ${isUser ? 'text-ink' : 'text-ink-2'}`}
             style={{ textWrap: 'pretty' }}>
          {m.text}
        </div>
        {m.tools && (
          <div className="mt-2.5 flex flex-col gap-1 items-start">
            {m.tools.map((tool, i) => <ToolPill key={i} tool={tool} />)}
          </div>
        )}
      </div>
    </div>
  );
}

function ToolPill({ tool }) {
  return (
    <div className="inline-flex items-center gap-2.5 px-2.5 py-[5px] border border-line bg-surface rounded-sm font-mono text-[11px] text-ink-2 max-w-full">
      <span className="text-accent-ink font-semibold">{tool.name}</span>
      <span className="text-ink-3">›</span>
      <span className="text-ink-2 truncate">{tool.detail}</span>
    </div>
  );
}

function SessionFooter() {
  return (
    <div className="border-t border-line px-7 py-3.5 bg-surface flex items-center gap-3">
      <div className="flex-1 text-[12px] text-ink-2">
        Kontynuacja podmieni historię na terminal:{' '}
        <span className="font-mono text-ink">claude --resume s-9af2</span>
      </div>
      <button className="border border-line bg-surface px-3.5 py-2 rounded-md text-[12px] text-ink-2 hover:text-ink hover:bg-surface-soft transition-colors">
        Wyeksportuj transkrypt
      </button>
      <button className="inline-flex items-center gap-2 bg-ink text-surface px-4 py-2.5 rounded-md text-[12px] font-medium hover:opacity-90 transition-opacity">
        <Icon name="arrow" className="w-3 h-3" strokeWidth={2.5} />
        Kontynuuj w terminalu
      </button>
    </div>
  );
}

Object.assign(window, { SessionView });
