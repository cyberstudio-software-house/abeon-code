// Mock data — mirrors what the real app will read from
// ~/.claude/projects/<slug>/*.jsonl and `git status`.

const PROJECTS = [
  { id: 'monorepo-web',    name: 'monorepo-web',    path: '~/dev/acme/monorepo-web',  sessions: 24, branch: 'feat/session-mgr', open: true,  live: 1 },
  { id: 'lab-experiments', name: 'lab-experiments', path: '~/dev/lab-experiments',    sessions: 7,  branch: 'main',             open: false, live: 0 },
  { id: 'docs-site',       name: 'docs-site',       path: '~/dev/acme/docs-site',     sessions: 3,  branch: 'main',             open: false, live: 0 },
  { id: 'tauri-bridge',    name: 'tauri-bridge',    path: '~/dev/tauri-bridge',       sessions: 11, branch: 'wip/ipc',          open: false, live: 2 },
  { id: 'home-dashboard',  name: 'home-dashboard',  path: '~/dev/home-dashboard',     sessions: 2,  branch: 'main',             open: false, live: 0 },
];

const SESSIONS = [
  { id: 's-9af2', title: 'Build session manager UI',       turns: 47, when: '12 min temu',  active: true,  cost: '$1.84' },
  { id: 's-7c11', title: 'Migrate worker pool to Tauri 2', turns: 32, when: '2 godz. temu', active: false, cost: '$2.31' },
  { id: 's-5b08', title: 'Fix race condition in queue',    turns: 18, when: 'wczoraj',      active: false, cost: '$0.74' },
  { id: 's-4d12', title: 'Refactor auth flow',             turns: 64, when: '2 dni temu',   active: false, cost: '$3.02' },
  { id: 's-2e90', title: 'Add E2E tests for login',        turns: 22, when: '5 dni temu',   active: false, cost: '$0.92' },
];

const HISTORY = [
  {
    role: 'user',
    when: '14:30',
    text: 'Załóżmy, że robimy tę aplikację w Tauri 2. Zacznij od szkieletu komponentu listy sesji — sidebar po lewej, kolapsowalne projekty, max 5 widocznych sesji z opcją „załaduj starsze".',
  },
  {
    role: 'assistant',
    when: '14:31',
    text: 'OK. Zrobię to w trzech krokach: 1) komponent SidebarProject z stanem rozwinięcia, 2) hook useSessions(projectId, limit) z paginacją, 3) renderer SessionRow. Najpierw zerknę co już jest w repo.',
    tools: [
      { name: 'Read', detail: 'src/components/Sidebar.tsx' },
      { name: 'Glob', detail: 'src/**/*.tsx · 142 plików' },
    ],
  },
  {
    role: 'user',
    when: '14:33',
    text: 'Tak, leć. Pamiętaj, że sesje czytamy z ~/.claude/projects/<slug>/',
  },
  {
    role: 'assistant',
    when: '14:35',
    text: 'Jasne. Dodam też walidację schematu pliku sesji — widziałem że Claude czasem dorzuca pola, których nie znamy.',
    tools: [
      { name: 'Edit',  detail: 'src/components/SidebarProject.tsx · +84 −12' },
      { name: 'Write', detail: 'src/hooks/useSessions.ts · 96 linii' },
      { name: 'Bash',  detail: 'pnpm typecheck → ok' },
    ],
  },
];

const ACTIONS = [
  { id: 'dev',   label: 'pnpm dev',          hint: 'Vite + Tauri', running: true,  kbd: '⌘1', port: 5173 },
  { id: 'build', label: 'pnpm build',        hint: 'Produkcja',    running: false, kbd: '⌘2' },
  { id: 'test',  label: 'pnpm test --watch', hint: 'Vitest',       running: false, kbd: '⌘3' },
  { id: 'lint',  label: 'pnpm lint',         hint: 'Biome',        running: false, kbd: '⌘4' },
  { id: 'tauri', label: 'cargo tauri dev',   hint: 'Rust shell',   running: false, kbd: '⌘5' },
];

const GIT = {
  branch: 'feat/session-mgr',
  ahead: 3,
  behind: 0,
  files: [
    { path: 'src/components/SidebarProject.tsx', status: 'M', add: 84, del: 12 },
    { path: 'src/components/SessionRow.tsx',     status: 'A', add: 41, del: 0  },
    { path: 'src/hooks/useSessions.ts',          status: 'A', add: 96, del: 0  },
    { path: 'src/store/projects.ts',             status: 'M', add: 7,  del: 3  },
    { path: 'src-tauri/src/sessions.rs',         status: 'M', add: 28, del: 9  },
    { path: 'package.json',                      status: 'M', add: 2,  del: 1  },
  ],
};

Object.assign(window, { PROJECTS, SESSIONS, HISTORY, ACTIONS, GIT });
