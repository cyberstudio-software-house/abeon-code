// Top-level shell: window chrome + 3-column layout.

function App() {
  return (
    <div className="w-full h-screen flex flex-col text-[13px] leading-[1.5]">
      <WindowChrome />
      <div className="flex-1 grid min-h-0" style={{ gridTemplateColumns: '288px 1fr 320px' }}>
        <Sidebar />
        <SessionView />
        <RightPanel />
      </div>
    </div>
  );
}

function WindowChrome() {
  return (
    <div className="h-9 flex items-center gap-3.5 px-3.5 bg-bg border-b border-line">
      <div className="flex gap-[7px]">
        <span className="w-[11px] h-[11px] rounded-full bg-[#ec6a5e]" />
        <span className="w-[11px] h-[11px] rounded-full bg-[#f4be4f]" />
        <span className="w-[11px] h-[11px] rounded-full bg-[#61c454]" />
      </div>
      <div className="font-mono text-[11px] text-ink-3 tracking-wide">
        claude code · sessions
      </div>
      <div className="flex-1" />
      <div className="flex items-center gap-2.5 text-[11px] text-ink-2">
        <span className="inline-flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-good" />
          3 aktywne sesje
        </span>
        <span className="text-ink-3">·</span>
        <span className="font-mono">$4.07 dziś</span>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
